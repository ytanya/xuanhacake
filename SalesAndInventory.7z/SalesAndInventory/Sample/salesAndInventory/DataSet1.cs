﻿namespace skelot {
    
    
    public partial class DataSet1 {
    }
}
